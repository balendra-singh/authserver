﻿namespace Enterprise.AuthorizationClientServer.Core.Models
{
    public class ContainerDetailModel
    {
        public int Id { get; set; }
        public string ImageName { get; set; }
        public string DisplayName { get; set; }
        public int InstanceAllowed { get; set; }
        public int ThroughputAllowed { get; set; }
        public int LicenseType { get; set; }
        public bool IsValid { get; set; }
        public bool ContainerState { get; set; }
    }

    public class ContainerServiceModel
    {
        public string ImageName { get; set; }
        public string ContainerName { get; set; }
        public string DockerServiceName
        {
            get
            {
                if (!string.IsNullOrEmpty(ContainerName))
                {
                    string[] splitName = ContainerName.Split("_");
                    return $"{splitName[1]}_{splitName[2]}";
                }

                return null;
            }
        }
    }
}
