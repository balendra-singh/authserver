﻿using System;
using System.ComponentModel;
using System.Reflection;

namespace Enterprise.AuthorizationClientServer.Core.Models.Contracts
{
    public class ErrorCodes
    {
        public enum EnumServerCode
        {
            [Description("Success")]
            OK = 0,

            [Description("Null body received")]
            NullBody = 1,

            [Description("Unauthorized user")]
            UnAuthorized = 2,

            [Description("Internal Server Error")]
            ServerError = 3,

            [Description("Resource not found")]
            NotFound = 4,

            [Description("Invalid request")]
            BadRequest = 5,

            [Description("Resource only available for developers")]
            DeveloperOnly = 6,

            [Description("Empty resource returned")]
            EmptyResource = 7,

        }
    }

    public static class EnumExtension
    {
        public static string GetDescription(this Enum value)
        {
            Type type = value.GetType();
            string name = Enum.GetName(type, value);
            if (name != null)
            {
                FieldInfo field = type.GetField(name);
                if (field != null)
                {
                    DescriptionAttribute attr =
                           Attribute.GetCustomAttribute(field,
                             typeof(DescriptionAttribute)) as DescriptionAttribute;
                    if (attr != null)
                    {
                        return attr.Description;
                    }
                }
            }
            return "Unknown";
        }

        public static T ToEnum<T>(this string enumString)
        {
            return (T)Enum.Parse(typeof(T), enumString);
        }
    }
}
