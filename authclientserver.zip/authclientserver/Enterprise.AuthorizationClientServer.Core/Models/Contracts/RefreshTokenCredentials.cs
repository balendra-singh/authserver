﻿namespace Enterprise.AuthorizationClientServer.Core.Models.Contracts
{
    public class RefreshTokenCredentials
    {
        public string JwtToken { get; set; }
        public string RefreshToken { get; set; }
    }
}
