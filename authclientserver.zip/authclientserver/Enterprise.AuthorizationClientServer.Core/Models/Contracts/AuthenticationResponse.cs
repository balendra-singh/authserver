﻿using static Enterprise.AuthorizationClientServer.Core.Models.Contracts.ErrorCodes;

namespace Enterprise.AuthorizationClientServer.Core.Models.Contracts
{
    public class AuthenticationResponse
    {
        public string JwtToken { get; set; }
        public string RefreshToken { get; set; }
    }

    public class AuthAPIResponseModel
    {
        public EnumServerCode ErrorCode { get; set; }
        public string Description => ErrorCode.GetDescription();

        public string Data { get; set; }

    }
}
