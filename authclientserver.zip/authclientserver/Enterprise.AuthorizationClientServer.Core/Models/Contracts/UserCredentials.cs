﻿namespace Enterprise.AuthorizationClientServer.Core.Models.Contracts
{
    public class UserCredentials
    {
        //public string ClientId { get; set; }
        //public string ClientSecret { get; set; }

        public string ClientName { get; set; }
        public string Resource { get; set; }
    }
}
