﻿namespace Enterprise.AuthorizationClientServer.Core.Models
{
    public enum EnumContainerValidity
    {
        InValid = 0,
        Valid = 1,
    }
    public enum EnumContainerStatus
    {
        Stopped = 0,
        Running = 1,
    }

    public class InterServiceModel
    {
        public string Resource { get; set; }
    }
}
