﻿using Enterprise.IText.LicenseLib;
using System;
using System.Collections.Generic;

namespace Enterprise.AuthorizationClientServer.Core.Models
{
    public class ClientResource
    {
        public int Id { get; set; }
        public string ClientKey { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string ClientIPAddress { get; set; }
        public DateTime? LastPingReceivedDateTime { get; set; }
        public List<LicenseDetail> LicenseDetail { get; set; } = new List<LicenseDetail>();
    }

}
