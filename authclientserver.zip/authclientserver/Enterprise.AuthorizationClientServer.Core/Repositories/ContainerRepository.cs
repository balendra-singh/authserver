﻿using Enterprise.AuthorizationClientServer.Core.Models;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace Enterprise.AuthorizationClientServer.Core.Repositories
{
    public class ContainerRepository
    {
        public List<ContainerDetailModel> GetAllContainerDetailList(string webConnectionString)
        {
            List<ContainerDetailModel> ContainerDetailModelList = new List<ContainerDetailModel>();
            using (MySqlConnection mySqlConnection = new MySqlConnection(webConnectionString))
            {
                string query = "SELECT * from containerdetail;";
                mySqlConnection.Open();

                MySqlCommand command = new MySqlCommand(query, mySqlConnection);
                MySqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    ContainerDetailModelList.Add(
                        new ContainerDetailModel
                        {
                            Id = reader.GetInt32("Id"),
                            ImageName = reader.GetString("ImageName"),
                            DisplayName = reader.GetString("DisplayName"),
                            InstanceAllowed = reader.GetInt32("InstanceAllowed"),
                            ThroughputAllowed = reader.GetInt32("ThroughputAllowed"),
                            LicenseType = reader.GetInt32("LicenseType"),
                            IsValid = reader.GetBoolean("IsValid"),
                            ContainerState = reader.GetBoolean("ContainerState"),
                        });
                }
            }
            return ContainerDetailModelList;
        }

        public List<ContainerDetailModel> GetContainerDetailListByValidity(EnumContainerValidity containerValidity, string webConnectionString)
        {
            List<ContainerDetailModel> ContainerDetailModelList = new List<ContainerDetailModel>();
            using (MySqlConnection mySqlConnection = new MySqlConnection(webConnectionString))
            {
                string query = $"SELECT * from containerdetail where IsValid={(int)containerValidity} and ContainerState=1;";

                mySqlConnection.Open();

                MySqlCommand command = new MySqlCommand(query, mySqlConnection);
                MySqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    ContainerDetailModelList.Add(
                        new ContainerDetailModel
                        {
                            Id = reader.GetInt32("Id"),
                            ImageName = reader.GetString("ImageName"),
                            DisplayName = reader.GetString("DisplayName"),
                            InstanceAllowed = reader.GetInt32("InstanceAllowed"),
                            ThroughputAllowed = reader.GetInt32("ThroughputAllowed"),
                            LicenseType = reader.GetInt32("LicenseType"),
                            IsValid = reader.GetBoolean("IsValid"),
                            ContainerState = reader.GetBoolean("ContainerState"),
                        });
                }
            }
            return ContainerDetailModelList;
        }

        public void UpdateContainerStatus(string imageName, EnumContainerStatus containerStatus, string webConnectionString)
        {
            using (MySqlConnection mySqlConnection = new MySqlConnection(webConnectionString))
            {
                string query = $"update containerdetail set ContainerState={(int)containerStatus} where ImageName='{imageName}';";

                mySqlConnection.Open();

                MySqlCommand command = new MySqlCommand(query, mySqlConnection);
                command.ExecuteNonQuery();
            }
        }
    }
}
