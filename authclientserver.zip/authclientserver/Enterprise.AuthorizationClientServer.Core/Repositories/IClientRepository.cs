﻿using Enterprise.AuthorizationClientServer.Core.Models;
using Enterprise.IText.LicenseLib;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace Enterprise.AuthorizationClientServer.Core.Repositories
{
    public interface IClientRepository
    {
        IConfiguration Configuration { get; }

        ClientResource GetClientResourceByCredentials(string clientId, string clientSecret);
        ClientResource GetClientResourceById(string clientId, string clientSecret = "");
        List<LicenseDetail> GetLicenceDetailById(string clientId);
        LicenseDetail GetLicenceDetailByType(string clientId, EnumLicenseType enumLicenseType);
    }
}