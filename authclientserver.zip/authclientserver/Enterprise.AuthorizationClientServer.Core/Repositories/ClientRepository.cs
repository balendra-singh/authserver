﻿using Enterprise.AuthorizationClientServer.Core.Models;
using Enterprise.IText.LicenseLib;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Enterprise.AuthorizationClientServer.Core.Repositories
{
    public class ClientRepository : IClientRepository
    {
        public ClientRepository(IConfiguration configuration)
        {
            Configuration = configuration;
            connectionString = configuration.GetSection(nameof(connectionString)).Value;
        }

        public IConfiguration Configuration { get; }

        private readonly string connectionString;

        public ClientResource GetClientResourceById(string clientId, string clientSecret = "")
        {
            ClientResource clientResource = new ClientResource();

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string query = $"SELECT * FROM clientdetail c INNER JOIN licensedetail l on c.ClientKey = l.ClientKey where clientid='{clientId}'";

                if (!string.IsNullOrEmpty(clientSecret))
                {
                    query += $" AND clientsecret='{clientSecret}'";
                }

                MySqlCommand command = new MySqlCommand(query, conn);
                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    if (clientResource.Id == 0)
                    {
                        clientResource.ClientId = reader.GetString("ClientId");
                        clientResource.ClientSecret = reader.GetString("ClientSecret");
                        clientResource.ClientKey = reader.GetString("ClientKey");
                        clientResource.ClientIPAddress = reader["ClientIPAddress"] == DBNull.Value ? null : reader.GetString("ClientIPAddress");

                        if (reader["LastPingReceivedDateTime"] != DBNull.Value)
                        {
                            clientResource.LastPingReceivedDateTime = Convert.ToDateTime(reader["LastPingReceivedDateTime"]);
                        }
                    }

                    clientResource.LicenseDetail.Add(
                        new LicenseDetail
                        {
                            LicenseType = (EnumLicenseType)reader.GetInt32("LicenseType"),
                            IsValid = Convert.ToBoolean(reader["IsValid"]),
                            IsMultiCountryAllowed = Convert.ToBoolean(reader["IsMultiCountryAllowed"]),
                            MaxInstanceAllowed = Convert.ToInt32(reader["MaxInstanceAllowed"]),
                            MaxThroughputAllowed = Convert.ToInt32(reader["MaxThroughputAllowed"]),

                        });
                }
                conn.Close();
            }
            return clientResource;
        }

        public ClientResource GetClientResourceByCredentials(string clientId, string clientSecret)
        {
            return GetClientResourceById(clientId, clientSecret);
        }

        public List<LicenseDetail> GetLicenceDetailById(string clientId)
        {
            return GetClientResourceById(clientId).LicenseDetail;
        }

        public LicenseDetail GetLicenceDetailByType(string clientId, EnumLicenseType enumLicenseType)
        {
            return GetClientResourceById(clientId).LicenseDetail.Where(l => l.LicenseType == enumLicenseType).FirstOrDefault();
        }
    }
}
