﻿using Enterprise.IText.LicenseLib;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enterprise.AuthorizationClientServer.Core.Repositories
{
    internal class LicenseRepository
    {
        internal void UpdateLicenseDetail(List<LicenseDetail> licenseDetailModelList, string webConnectionString)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection(webConnectionString))
                {
                    StringBuilder queryBuilder = new StringBuilder();
                    mySqlConnection.Open();

                    foreach (LicenseDetail item in licenseDetailModelList)
                    {
                        queryBuilder.Append($"update containerdetail set InstanceAllowed={item.MaxInstanceAllowed}, ThroughputAllowed={item.MaxThroughputAllowed}, IsValid={item.IsValid} where LicenseType={(int)item.LicenseType};");
                    }

                    string updatedRowsLicenseType = string.Join(",", licenseDetailModelList.Select(l => (int)l.LicenseType).ToList());
                    if (!string.IsNullOrEmpty(updatedRowsLicenseType))
                    {
                        queryBuilder.Append($"update containerdetail set InstanceAllowed=0, ThroughputAllowed=0, IsValid=0 where LicenseType not in ({updatedRowsLicenseType});");
                    }

                    MySqlCommand command = new MySqlCommand(queryBuilder.ToString(), mySqlConnection);
                    command.ExecuteNonQuery();
                }
            }
            catch (MySqlException)
            {
            }
        }
    }
}

