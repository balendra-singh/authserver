﻿using Enterprise.AuthorizationClientServer.Core.Models;
using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using Enterprise.AuthorizationClientServer.Core.Repositories;
using Enterprise.IText.LicenseLib;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NLog;
using RestSharp;
using System;
using System.Collections.Generic;

namespace Enterprise.AuthorizationClientServer.Core.BusinessLogic
{
    public class LicenseManager
    {
        private readonly LicenseRepository licenseRepository;
        private readonly ContainerRepository containerRepository;
        private readonly string licenseServerUrl;
        private readonly string webconnectionString;
        private readonly AESHelper aesHelper = new AESHelper();
        private const int API_Timeout = 60000;

        private const string AES_KEY = "/Oqn6q/HmK9lVwaKOaQnlWAJD0luhs9KXQT2nWbcAOA=";
        private const string IV = "qQamp48cLrnW3EkNyChpwQ==";

        private readonly Logger Log = LogManager.GetCurrentClassLogger();
        private readonly IMemoryCache memoryCache;

        public LicenseManager(IConfiguration configuration, IMemoryCache memoryCache)
        {
            licenseRepository = new LicenseRepository();
            containerRepository = new ContainerRepository();
            Configuration = configuration;
            this.memoryCache = memoryCache;
            licenseServerUrl = Configuration.GetSection(nameof(licenseServerUrl)).Value;
            webconnectionString = Configuration.GetSection(nameof(webconnectionString)).Value;
        }

        public IConfiguration Configuration { get; }

        public bool IsValidLicense(string token, ref bool isInitialSetup)
        {
            try
            {
                RestClient client = new RestClient(licenseServerUrl)
                {
                    Timeout = API_Timeout
                };
                RestRequest request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", $"Bearer {token}");
                IRestResponse response = client.Execute(request);
                if (response.IsSuccessful)
                {
                    AuthAPIResponseModel authAPIResponseModel = JsonConvert.DeserializeObject<AuthAPIResponseModel>(response.Content);
                    if (authAPIResponseModel.ErrorCode == ErrorCodes.EnumServerCode.OK)
                    {
                        string decryptedData = aesHelper.Decrypt(authAPIResponseModel.Data, IV, AES_KEY);
                        List<LicenseDetail> licenseDetailModelList = JsonConvert.DeserializeObject<List<LicenseDetail>>(decryptedData);

                        if (licenseDetailModelList != null && licenseDetailModelList.Count > 0)
                        {
                            foreach (LicenseDetail license in licenseDetailModelList)
                            {
                                if (!memoryCache.TryGetValue(license.LicenseType, out object value))
                                {
                                    memoryCache.Set(license.LicenseType, license);
                                }
                                else
                                {
                                    memoryCache.Remove(license.LicenseType);
                                    memoryCache.Set(license.LicenseType, license);
                                }
                            }


                            #region Initial Setup
                            if (isInitialSetup)
                            {
                                Log.Info("Starting up for initial docker container startup");
                                ServiceManager.InitialSetupDockerContainer();
                                isInitialSetup = false;
                                Log.Info("Completed initial docker container startup");
                            }
                            #endregion

                            licenseRepository.UpdateLicenseDetail(licenseDetailModelList, webconnectionString);

                            Log.Info("Validating license completed successfully");
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Validating resouce :: " + ex.ToString());
            }

            Log.Info("Validating license failed");
            return false;
        }

        public List<ContainerDetailModel> GetInvalidLicenseContainer()
        {
            try
            {
                return containerRepository.GetContainerDetailListByValidity(EnumContainerValidity.InValid, webconnectionString);
            }
            catch (Exception)
            {
                //Log.Error("GetInvalidLicenseContainer :: " + ex.ToString());
                return null;
            }

        }

        public List<ContainerDetailModel> GetValidLicenseContainer()
        {
            try
            {
                return containerRepository.GetContainerDetailListByValidity(EnumContainerValidity.Valid, webconnectionString);
            }
            catch (Exception)
            {
                //Log.Error("GetInvalidLicenseContainer :: " + ex.ToString());
                return null;
            }
        }
    }
}
