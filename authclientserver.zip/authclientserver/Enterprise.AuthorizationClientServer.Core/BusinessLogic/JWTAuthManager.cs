﻿using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using Newtonsoft.Json;
using NLog;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;
using RestSharp;
using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Enterprise.AuthorizationClientServer.Core.BusinessLogic
{
    public class JWTAuthManager
    {
        private readonly Logger Log = LogManager.GetCurrentClassLogger();
        private readonly string ethernetDeviceName;
        private string clientId;
        private string clientSecret;
        private RSACryptoServiceProvider publicKey;
        private readonly RSACryptoServiceProvider privateKey;
        private readonly string authenticateUrl;
        private readonly string refreshTokenUrl;

        public JWTAuthManager(string authenticateUrl, string refreshTokenUrl, string ethernetDeviceName)
        {
            this.authenticateUrl = authenticateUrl;
            this.refreshTokenUrl = refreshTokenUrl;
            this.ethernetDeviceName = ethernetDeviceName;
        }

        public AuthenticationResponse GetToken()
        {
#if !DEBUG

            #region Get ClientId

            string command = $"\"sudo dmidecode -s system-uuid\"";
            Process proc = new Process();
            proc.StartInfo.FileName = "/bin/bash";
            proc.StartInfo.Arguments = "-c " + command;
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.RedirectStandardOutput = true;
            proc.Start();
            clientId = proc.StandardOutput.ReadToEnd()?.Trim();

            #endregion

            #region Get Client Secret

            command = $"\"cat /sys/class/net/{ethernetDeviceName}/address\"";
            proc = new Process();
            proc.StartInfo.FileName = "/bin/bash";
            proc.StartInfo.Arguments = "-c " + command;
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.RedirectStandardOutput = true;
            proc.Start();
            clientSecret = proc.StandardOutput.ReadToEnd()?.Trim();

            #endregion

            if (string.IsNullOrEmpty(clientId) || string.IsNullOrEmpty(clientSecret))
            {
                throw new Exception("client Id or client secret missing!");
            }
#else
            clientId = "BC1DA251-C0F0-479F-B383-4FC4B5C966A0";
            clientSecret = "02:00:65:35:9d:f1";
#endif

            publicKey = GetPublicKeyFromPemFile("keypairs/rsa.public");
            string encryptedResource = Encrypt(clientId);


            #region Fetch token

            RestClient client = new RestClient(authenticateUrl);
            RestRequest request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "{ \"resource\": \"" + encryptedResource + "\",  \"clientname\" : \"" + clientSecret + "\" }", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            if (response == null || string.IsNullOrEmpty(response?.Content))
            {
                throw new Exception("Token generation failed due to null response from license server.");
            }

            AuthAPIResponseModel responseData = JsonConvert.DeserializeObject<AuthAPIResponseModel>(response.Content);
            if (responseData.ErrorCode == 0)
            {
                return JsonConvert.DeserializeObject<AuthenticationResponse>(responseData.Data);
            }
            else
            {
                Log.Error($"Authentication failed response : {JsonConvert.SerializeObject(responseData)}");
                throw new Exception("Authentication Failed!");
            }
            #endregion
        }

        public AuthenticationResponse RefreshToken(AuthenticationResponse jwtAuthenticationTokens)
        {
            RestClient client = new RestClient(refreshTokenUrl);

            RestRequest request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "{\r\n    \"jwtToken\": \"" + jwtAuthenticationTokens.JwtToken + "\",\r\n    \"refreshToken\": \"" + jwtAuthenticationTokens.RefreshToken + "\"\r\n}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            if (response == null || string.IsNullOrEmpty(response?.Content))
            {
                Log.Error("Refresh Token generation failed!");
                return null;
            }

            AuthAPIResponseModel responseData = JsonConvert.DeserializeObject<AuthAPIResponseModel>(response.Content);
            if (responseData.ErrorCode == 0)
            {
                return JsonConvert.DeserializeObject<AuthenticationResponse>(responseData.Data);
            }
            else
            {
                Log.Error($"Refresh token generation failed response : {JsonConvert.SerializeObject(responseData)}");
                return null;
            }
        }

        public string Encrypt(string text)
        {
            byte[] encryptedBytes = publicKey.Encrypt(Encoding.UTF8.GetBytes(text), false);
            return Convert.ToBase64String(encryptedBytes);
        }

        private RSACryptoServiceProvider GetPublicKeyFromPemFile(string filePath)
        {
            using (TextReader publicKeyTextReader = new StringReader(File.ReadAllText(filePath)))
            {
                RsaKeyParameters publicKeyParam = (RsaKeyParameters)new PemReader(publicKeyTextReader).ReadObject();

                RSAParameters rsaParams = DotNetUtilities.ToRSAParameters(publicKeyParam);

                RSACryptoServiceProvider csp = new RSACryptoServiceProvider();
                csp.ImportParameters(rsaParams);
                return csp;
            }
        }

        private RSACryptoServiceProvider GetPrivateKeyFromPemFile(string filePath)
        {
            using (TextReader privateKeyTextReader = new StringReader(File.ReadAllText(filePath)))
            {
                AsymmetricCipherKeyPair readKeyPair = (AsymmetricCipherKeyPair)new PemReader(privateKeyTextReader).ReadObject();

                RSAParameters rsaParams = DotNetUtilities.ToRSAParameters((RsaPrivateCrtKeyParameters)readKeyPair.Private);
                RSACryptoServiceProvider csp = new RSACryptoServiceProvider();
                csp.ImportParameters(rsaParams);
                return csp;
            }
        }
    }
}
