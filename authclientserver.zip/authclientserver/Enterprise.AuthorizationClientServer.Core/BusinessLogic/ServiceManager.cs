﻿using NLog;
using System;
using System.Diagnostics;
using System.IO;
using System.Net;

namespace Enterprise.AuthorizationClientServer.Core.BusinessLogic
{
    public class ServiceManager
    {
        private static readonly Logger Log = LogManager.GetCurrentClassLogger();

        public static void StartContainer(string dockerServiceName)
        {
            //string command = $"\"docker start $(docker ps --all -q --filter ancestor={imageName})\"";
            string command = $"\"docker-compose up -d --remove-orphans {dockerServiceName}\"";
            using (Process proc = new Process())
            {
                proc.StartInfo.FileName = "/bin/bash";
                proc.StartInfo.Arguments = "-c " + command;
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.Start();
                proc.WaitForExit();
            }
        }

        public static void InitialSetupDockerContainer()
        {
            try
            {
                string command = $"\"cd /home/powersmpp/powersmpp/ && docker-compose up -d\"";
                using (Process proc = new Process())
                {
                    proc.StartInfo.FileName = "/bin/bash";
                    proc.StartInfo.Arguments = "-c " + command;
                    proc.StartInfo.UseShellExecute = false;
                    proc.StartInfo.RedirectStandardOutput = true;
                    proc.Start();
                    proc.WaitForExit();
                }
            }
            catch (Exception)
            {

            }
        }

        public static void StopDockerContainers()
        {
            
                string command = $"\"cd /home/powersmpp/powersmpp/ && docker-compose down\"";
                using (Process proc = new Process())
                {
                    proc.StartInfo.FileName = "/bin/bash";
                    proc.StartInfo.Arguments = "-c " + command;
                    proc.StartInfo.UseShellExecute = false;
                    proc.StartInfo.RedirectStandardOutput = true;
                    proc.Start();
                    proc.WaitForExit();
                }
           
        }

        public static void StopContainer(string imageName, bool isRemoveActionRequired = true)
        {
            string command = $"\"docker stop $(docker ps --all -q --filter ancestor={imageName})\"";
            using (Process proc = new Process())
            {
                proc.StartInfo.FileName = "/bin/bash";
                proc.StartInfo.Arguments = "-c " + command;
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.Start();
                proc.WaitForExit();
            }

            if (isRemoveActionRequired)
            {
                RemoveContainer(imageName);
            }
        }

        public static void RemoveContainer(string imageName)
        {
            //string command = "\"docker ps -a | awk '{ print $1,$2 }' | grep " + imageName + " | awk '{print $1 }' | xargs -I {} docker rm {}\"";
            //Process proc = new Process();
            //proc.StartInfo.FileName = "/bin/bash";
            //proc.StartInfo.Arguments = "-c " + command;
            //proc.StartInfo.UseShellExecute = false;
            //proc.StartInfo.RedirectStandardOutput = true;
            //proc.Start();
            //proc.WaitForExit();

            string command = $"\" docker container rm $(docker ps --all -q --filter ancestor={imageName}) -f\"";
            using (Process proc = new Process())
            {
                proc.StartInfo.FileName = "/bin/bash";
                proc.StartInfo.Arguments = "-c " + command;
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.Start();
                proc.WaitForExit();
            }

        }

        public static bool GetContainerStatus(string imageName)
        {
            string command = $"\"docker ps | grep \"{imageName}\" | wc -l\"";

            using (Process proc = new Process())
            {
                proc.StartInfo.FileName = "/bin/bash";
                proc.StartInfo.Arguments = "-c " + command;
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.Start();
                string result = proc.StandardOutput.ReadToEnd();
                if (int.TryParse(result.Trim(), out int numberOfContainerRunning))
                {
                    if (numberOfContainerRunning > 0)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static string GetPDUCaptureFileName(string host, string filter, int timeInterval, string pduFilePath)
        {
            TimeSpan span = new TimeSpan(0, timeInterval, 0);

            string outputFileName = $"{DateTime.UtcNow.ToString("dd_MMM_yyyy_HH:mm:ss")}.pcap";
            string outputFile = Path.Combine(pduFilePath, outputFileName);
            string scriptPath = Path.Combine(pduFilePath, "pducapture.sh");
            string filterExp = $"-w {outputFile} -G {span.TotalSeconds} -W 1 {filter}";


            using (Process proc = new Process())
            {
                proc.StartInfo = new ProcessStartInfo() { FileName = "/bin/bash", Arguments = $"{scriptPath} \"{host.Trim()}\" \"{filterExp}\"" };

                Log.Info("startInfo.Arguments : " + proc.StartInfo.Arguments);

                if (proc.Start())
                {
                    Log.Info($"Requested Live PDU Capture for host: {host}, filter: {filter} and file-path: {pduFilePath} for {timeInterval} minutes");

                    return outputFileName;
                }
                else
                {
                    return HttpStatusCode.BadRequest.ToString();
                }
            }
        }

        public static string ExecuteCommand(string command)
        {
            using (Process p = new Process())
            {
                p.StartInfo.FileName = "/bin/bash";
                p.StartInfo.Arguments = "-c " + command;
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.RedirectStandardOutput = true;

                if (p.Start())
                {
                    Log.Info($"Successfully executed command: {command}");
                    return p.StandardOutput.ReadToEnd()?.Trim();
                }

                Log.Error($"Failed to execute command: {command}");
                return string.Empty;
            }
        }
    }
}
