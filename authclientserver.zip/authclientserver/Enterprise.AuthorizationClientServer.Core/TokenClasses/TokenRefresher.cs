﻿using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

namespace Enterprise.AuthorizationClientServer.Core.TokenClasses
{
    public class TokenRefresher : ITokenRefresher
    {
        private readonly byte[] key;
        private readonly IJWTAuthenticationManager jWTAuthenticationManager;

        public TokenRefresher(byte[] key, IJWTAuthenticationManager jWTAuthenticationManager)
        {
            this.key = key;
            this.jWTAuthenticationManager = jWTAuthenticationManager;
        }

        public AuthenticationResponse Refresh(RefreshTokenCredentials refreshCred)
        {
            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();

            System.Security.Claims.ClaimsPrincipal pricipal = tokenHandler.ValidateToken(refreshCred.JwtToken,
                new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ValidateLifetime = false //here we are saying that we don't care about the token's expiration date
                }, out SecurityToken validatedToken);

            JwtSecurityToken jwtToken = validatedToken as JwtSecurityToken;

            if (jwtToken == null || !jwtToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
            {
                throw new SecurityTokenException("Invalid token passed!");
            }

            string userName = pricipal.Identity.Name;
            if (refreshCred.RefreshToken != jWTAuthenticationManager.UsersRefreshTokens[userName])
            {
                throw new SecurityTokenException("Invalid token passed!");
            }

            return jWTAuthenticationManager.Authenticate(userName, pricipal.Claims.ToArray());
        }
    }
}
