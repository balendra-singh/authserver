﻿namespace Enterprise.AuthorizationClientServer.Core.TokenClasses
{
    public interface IRefreshTokenGenerator
    {
        string GenerateToken();
    }
}
