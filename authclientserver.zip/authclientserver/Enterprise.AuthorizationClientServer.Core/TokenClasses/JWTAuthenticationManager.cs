﻿using Enterprise.AuthorizationClientServer.Core.Models;
using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using Enterprise.AuthorizationClientServer.Core.Repositories;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Enterprise.AuthorizationClientServer.Core.TokenClasses
{
    public class JWTAuthenticationManager : IJWTAuthenticationManager
    {
        public IDictionary<string, string> UsersRefreshTokens { get; set; }

        private readonly string tokenKey;
        private readonly IRefreshTokenGenerator refreshTokenGenerator;
        private readonly IClientRepository clientRepository;

        public JWTAuthenticationManager(string tokenKey, IRefreshTokenGenerator refreshTokenGenerator, IClientRepository clientRepository)
        {
            this.tokenKey = tokenKey;
            this.refreshTokenGenerator = refreshTokenGenerator;
            this.clientRepository = clientRepository;

            UsersRefreshTokens = new Dictionary<string, string>();
        }

        public AuthenticationResponse Authenticate(string clientId, Claim[] claims)
        {
            string token = GenerateTokenString(clientId, expires: DateTime.Now.AddHours(6), claims);
            string refreshToken = refreshTokenGenerator.GenerateToken();

            if (UsersRefreshTokens.ContainsKey(clientId))
            {
                UsersRefreshTokens[clientId] = refreshToken;
            }
            else
            {
                UsersRefreshTokens.Add(clientId, refreshToken);
            }

            return new AuthenticationResponse
            {
                JwtToken = token,
                RefreshToken = refreshToken
            };
        }

        public AuthenticationResponse Authenticate(string clientId, string clientSecret)
        {
            ClientResource clientDetail = clientRepository.GetClientResourceByCredentials(clientId, clientSecret);
            if (clientDetail == null || string.IsNullOrEmpty(clientDetail?.ClientId))
            {
                return null;
            }

            string token = GenerateTokenString(clientId, expires: DateTime.Now.AddHours(6));
            string refreshToken = refreshTokenGenerator.GenerateToken();

            if (UsersRefreshTokens.ContainsKey(clientId))
            {
                UsersRefreshTokens[clientId] = refreshToken;
            }
            else
            {
                UsersRefreshTokens.Add(clientId, refreshToken);
            }

            return new AuthenticationResponse
            {
                JwtToken = token,
                RefreshToken = refreshToken
            };
        }

        private string GenerateTokenString(string clientId, DateTime expires, Claim[] claims = null)
        {
            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();

            byte[] key = Encoding.ASCII.GetBytes(tokenKey);

            SecurityTokenDescriptor tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(
                 claims ?? new Claim[]
                {
                    new Claim(ClaimTypes.Name, clientId)
                }),

                Expires = expires,
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            return tokenHandler.WriteToken(tokenHandler.CreateToken(tokenDescriptor));
        }
    }
}
