﻿using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using System.Collections.Generic;
using System.Security.Claims;

namespace Enterprise.AuthorizationClientServer.Core.TokenClasses
{
    public interface IJWTAuthenticationManager
    {
        AuthenticationResponse Authenticate(string clientId, string clientSecret);
        IDictionary<string, string> UsersRefreshTokens { get; set; }
        AuthenticationResponse Authenticate(string clientId, Claim[] claims);
    }
}
