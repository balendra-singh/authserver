﻿using Enterprise.AuthorizationClientServer.Core.Models.Contracts;

namespace Enterprise.AuthorizationClientServer.Core.TokenClasses
{
    public interface ITokenRefresher
    {
        AuthenticationResponse Refresh(RefreshTokenCredentials refreshCred);
    }
}
