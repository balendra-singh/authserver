﻿using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using Enterprise.AuthorizationClientServer.Core.Repositories;
using Enterprise.IText.LicenseLib;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NLog;
using System;
using System.Collections.Generic;
using static Enterprise.AuthorizationClientServer.Core.Models.Contracts.ErrorCodes;

namespace Enterprise.AuthorizationServer.API.Controllers
{
    [Authorize]
    [ApiController]
    public class LicenseController : ControllerBase
    {
        private readonly IClientRepository clientRepository;
        private readonly AESHelper aesHelper;
        private readonly Logger Log = LogManager.GetCurrentClassLogger();

        private const string AES_KEY = "/Oqn6q/HmK9lVwaKOaQnlWAJD0luhs9KXQT2nWbcAOA=";
        private const string IV = "qQamp48cLrnW3EkNyChpwQ==";

        public LicenseController(IClientRepository clientRepository)
        {
            this.clientRepository = clientRepository;
            aesHelper = new AESHelper();
        }

        [HttpGet("api/license")]
        public IActionResult GetLicenceDetails()
        {
            try
            {
                List<LicenseDetail> details = clientRepository.GetLicenceDetailById(User.Identity.Name);
                if (details != null && details.Count > 0)
                {
                    return Ok(
                       new AuthAPIResponseModel
                       {
                           ErrorCode = EnumServerCode.OK,
                           Data = aesHelper.Encrypt(JsonConvert.SerializeObject(details), IV, AES_KEY)
                       });
                }

                return Ok(
                       new AuthAPIResponseModel
                       {
                           ErrorCode = EnumServerCode.NotFound,
                       });
            }
            catch (Exception ex)
            {
                Log.Error("GetLicenceDetails :: " + ex.ToString());
                return Ok(
                       new AuthAPIResponseModel
                       {
                           ErrorCode = EnumServerCode.ServerError,
                       });
            }

        }

        [HttpGet("api/license/{licenseType:int}")]
        public IActionResult GetLicenceDetails(int licenseType)
        {
            try
            {
                LicenseDetail details = clientRepository.GetLicenceDetailByType(User.Identity.Name, (EnumLicenseType)licenseType);
                if (details != null)
                {
                    return Ok(
                       new AuthAPIResponseModel
                       {
                           ErrorCode = EnumServerCode.OK,
                           Data = aesHelper.Encrypt(JsonConvert.SerializeObject(details), IV, AES_KEY)
                       });
                }

                return Ok(
                       new AuthAPIResponseModel
                       {
                           ErrorCode = EnumServerCode.NotFound,
                       });
            }
            catch (Exception ex)
            {
                Log.Error("GetLicenceDetails By Type :: " + ex.ToString());
                return Ok(
                       new AuthAPIResponseModel
                       {
                           ErrorCode = EnumServerCode.ServerError,
                       });
            }

        }

        [HttpGet("api/clientid")]
        public IActionResult GetClientId()
        {
#if DEBUG
            return Ok(
                       new AuthAPIResponseModel
                       {
                           ErrorCode = EnumServerCode.OK,
                           Data = User?.Identity?.Name
                       });
#else
            return Ok(
                        new AuthAPIResponseModel
                        {
                            ErrorCode = EnumServerCode.DeveloperOnly,
                        });

#endif

        }
    }
}
