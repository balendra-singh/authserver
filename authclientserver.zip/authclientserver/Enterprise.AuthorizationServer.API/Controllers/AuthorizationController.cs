﻿using Enterprise.AuthorizationClientServer.Core.BusinessLogic;
using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using Enterprise.AuthorizationClientServer.Core.TokenClasses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NLog;
using System;
using static Enterprise.AuthorizationClientServer.Core.Models.Contracts.ErrorCodes;

namespace Enterprise.AuthorizationServer.API.Controllers
{
    [Authorize]
    [ApiController]
    public class AuthorizationController : ControllerBase
    {
        private readonly Logger Log = LogManager.GetCurrentClassLogger();
        private readonly IJWTAuthenticationManager jWTAuthenticationManager;
        private readonly ITokenRefresher tokenRefresher;

        public AuthorizationController(IJWTAuthenticationManager jWTAuthenticationManager, ITokenRefresher tokenRefresher)
        {
            this.jWTAuthenticationManager = jWTAuthenticationManager;
            this.tokenRefresher = tokenRefresher;
        }

        [AllowAnonymous]
        [HttpPost("api/authenticate")]
        public IActionResult Authenticate([FromBody] UserCredentials userCred)
        {
            try
            {
                if (userCred == null)
                {
                    return Ok(
                        new AuthAPIResponseModel
                        {
                            ErrorCode = EnumServerCode.NullBody
                        });
                }

                Log.Info("UserCredentials " + JsonConvert.SerializeObject(userCred));

                System.Security.Cryptography.RSACryptoServiceProvider privateKey = RSAHelper.GetPrivateKeyFromPemFile("keypairs/rsa.private");
                string decryptedResource = RSAHelper.Decrypt(userCred.Resource, privateKey);

                AuthenticationResponse token = jWTAuthenticationManager.Authenticate(decryptedResource, userCred.ClientName);

                if (token == null)
                {
                    return Ok(
                       new AuthAPIResponseModel
                       {
                           ErrorCode = EnumServerCode.UnAuthorized
                       });
                }

                return Ok(new AuthAPIResponseModel
                {
                    ErrorCode = EnumServerCode.OK,
                    Data = JsonConvert.SerializeObject(token)
                });
            }
            catch (Exception ex)
            {
                Log.Error("Authenticate :: " + ex.ToString());

                return Ok(new AuthAPIResponseModel
                {
                    ErrorCode = EnumServerCode.ServerError,
                });
            }
        }

        [AllowAnonymous]
        [HttpPost("api/refresh")]
        public IActionResult Refresh([FromBody] RefreshTokenCredentials refreshCred)
        {
            try
            {
                AuthenticationResponse token = tokenRefresher.Refresh(refreshCred);

                if (token == null)
                {
                    return Ok(
                        new AuthAPIResponseModel
                        {
                            ErrorCode = EnumServerCode.UnAuthorized
                        });
                }

                return Ok(new AuthAPIResponseModel
                {
                    ErrorCode = EnumServerCode.UnAuthorized,
                    Data = JsonConvert.SerializeObject(token)

                });
            }
            catch (Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException) { }
            catch (Exception) { }

            return Ok(new AuthAPIResponseModel
            {
                ErrorCode = EnumServerCode.BadRequest,
            });
        }
    }
}
