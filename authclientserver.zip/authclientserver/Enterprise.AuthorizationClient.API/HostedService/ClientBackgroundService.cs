﻿using Enterprise.AuthorizationClientServer.Core.BusinessLogic;
using Enterprise.AuthorizationClientServer.Core.Models;
using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using MySql.Data.MySqlClient;
using NLog;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Enterprise.AuthorizationClient.API.HostedService
{
    public class ClientBackgroundService : IHostedService, IDisposable
    {
        private readonly Logger Log = LogManager.GetCurrentClassLogger();

        private Timer checkLicenceTimer;
        private AuthenticationResponse jwtAuthenticationTokens;
        private TimerCallback checkLicenceTimerCallback;
        private readonly TimerCallback tokenTimerCallback;
        private readonly Timer tokenTimer;
        private static int invalidLicenseCounter = 0;
        private readonly JWTAuthManager jwtAuthManager;
        private readonly IConfiguration configuration;
        private readonly IMemoryCache memoryCache;

        private bool IsInitialSetup = true;

        public ClientBackgroundService(IConfiguration configuration, IMemoryCache memoryCache)
        {
            this.configuration = configuration;
            this.memoryCache = memoryCache;
            jwtAuthManager = new JWTAuthManager(configuration.GetSection("tokenrUrl").Value, configuration.GetSection("refreshTokenrUrl").Value, configuration.GetSection("device").Value);
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            try
            {
                Log.Info("Starting Client Authentication Service");

                checkLicenceTimerCallback = new TimerCallback(checkLicenceTimer_Elapsed);
                checkLicenceTimer = new Timer(checkLicenceTimerCallback);
                checkLicenceTimer.Change(1000, Timeout.Infinite);
            }
            catch (Exception ex)
            {
                Log.Error("Exception on startup StartAsync :: " + ex.ToString());
            }

            return Task.CompletedTask;
        }

        private void tokenTimer_Elapsed(object state)
        {
            try
            {
                if (jwtAuthenticationTokens != null)
                {
                    jwtAuthenticationTokens = jwtAuthManager.RefreshToken(jwtAuthenticationTokens);
                }

                if (jwtAuthenticationTokens is null)
                {
                    jwtAuthenticationTokens = jwtAuthManager.GetToken();    // hit on timer based
                }

                if (jwtAuthenticationTokens == null)
                {
                    ServiceManager.StopDockerContainers();
                }
            }
            catch (Exception ex)
            {
                Log.Error("tokenTimer_Elapsed exception stopping all containers :: " + ex.ToString());
            }
            finally
            {
                tokenTimer.Change(10 * 60 * 1000, Timeout.Infinite);
            }
        }

        private void checkLicenceTimer_Elapsed(object state)
        {
            try
            {
                checkLicenceTimer.Change(Timeout.Infinite, Timeout.Infinite);

                try
                {
                    jwtAuthenticationTokens = jwtAuthManager.GetToken();
                }
                catch (Exception ex)
                {
                    Log.Error("Exception while generating token: " + ex.ToString());
                }

                if (jwtAuthenticationTokens == null)
                {
                    if (invalidLicenseCounter <= 3)
                    {
                        return;
                    }

                    Log.Info($"Invalid License counter reached to max attempts {invalidLicenseCounter}. Stopping all containers.");
                    ServiceManager.StopDockerContainers();
                    StopAsync(CancellationToken.None);
                }
                else
                {
                    LicenseManager licenseManager = new LicenseManager(configuration, memoryCache);
                    if (!licenseManager.IsValidLicense(jwtAuthenticationTokens.JwtToken, ref IsInitialSetup))
                    {
                        invalidLicenseCounter += 1;

                        if (invalidLicenseCounter > 3)
                        {
                            //destroy everything!!!
                            ServiceManager.StopDockerContainers();

                        }
                    }
                    else
                    {
                        invalidLicenseCounter = 0;
                    }

                    if (IsInitialSetup)
                    {
                        //start containers if not running
                        StartValidContainers(licenseManager);
                    }

                    //always check and stop invalid image container(s)
                    StopInvalidContainers(licenseManager);
                }
            }
            catch (Exception ex)
            {
                Log.Error("checkLicenceTimer_Elapsed :: " + ex.ToString());
            }
            finally
            {
                if (invalidLicenseCounter <= 3)
                {
                    checkLicenceTimer.Change(60 * 60 * 1000, Timeout.Infinite);
                }
                else
                {
                    Log.Info("Stopping all the containers and service due to invalid license.");
                    invalidLicenseCounter = 0;
                    StopAsync(CancellationToken.None);
                }
            }
        }

        private void StartValidContainers(LicenseManager licenseManager)
        {
            try
            {
                List<ContainerDetailModel> validLicenseContainerList = licenseManager.GetValidLicenseContainer();
                if (validLicenseContainerList?.Count > 0)
                {
                    //Log.Info("At checkLicenceTimer_Elapsed VALID license found. Starting containers, ignore if already started");
                    foreach (ContainerDetailModel container in validLicenseContainerList)
                    {
                        ServiceManager.StartContainer(container.ImageName);
                        //Log.Info("Trying to start container with image name : " + container.ImageName);
                    }
                    invalidLicenseCounter = 0;
                }
            }
            catch (MySqlException)
            {
            }
        }

        private void StopInvalidContainers(LicenseManager licenseManager)
        {
            try
            {
                List<ContainerDetailModel> invalidLicenseContainerList = licenseManager.GetInvalidLicenseContainer();
                if (invalidLicenseContainerList?.Count > 0)
                {
                    //Log.Info("At checkLicenceTimer_Elapsed invalid license found. Stopping containers!");
                    foreach (AuthorizationClientServer.Core.Models.ContainerDetailModel container in invalidLicenseContainerList)
                    {
                        ServiceManager.StopContainer(container.ImageName);
                        //Log.Info("Stopped container with image name : " + container.ImageName);
                    }
                    invalidLicenseCounter = 0;
                }
            }
            catch (MySqlException)
            {
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            Log.Info("Stopping Client Authentication Service and all the containers");
            ServiceManager.StopDockerContainers();
            Dispose();

            return Task.CompletedTask;
        }


        public void Dispose()
        {
            checkLicenceTimer?.Dispose();
        }
    }
}
