using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System.IO;

namespace Enterprise.AuthorizationClient.API
{
    public class Program
    {
        private static string appEndpoint = string.Empty;
        public static void Main(string[] args)
        {
            IConfigurationRoot config = new ConfigurationBuilder()
                        .AddJsonFile("appsettings.json", optional: false)
                        .Build();

            appEndpoint = config.GetSection(nameof(appEndpoint)).Value;

            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseContentRoot(Directory.GetCurrentDirectory());
                webBuilder.UseUrls(appEndpoint);
                webBuilder.UseStartup<Startup>();
            });
        }
    }
}
