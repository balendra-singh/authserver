﻿using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using Enterprise.IText.LicenseLib;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using NLog;
using System;

namespace Enterprise.AuthorizationClient.API.Controllers
{
    public class LicenseController : Controller
    {
        private readonly Logger Log = LogManager.GetCurrentClassLogger();
        private readonly IMemoryCache memoryCache;
        private readonly AESHelper aesHelper;

        private const string AES_KEY = "/Oqn6q/HmK9lVwaKOaQnlWAJD0luhs9KXQT2nWbcAOA=";
        private const string IV = "qQamp48cLrnW3EkNyChpwQ==";

        public LicenseController(IMemoryCache memoryCache)
        {
            this.memoryCache = memoryCache;

            aesHelper = new AESHelper();
        }

        [HttpGet("/api/validate/{enumLicenseType:int}")]
        public IActionResult ValidateLicence(int enumLicenseType)
        {
            try
            {
                string jsonData = string.Empty;

                LicenseDetail license = GetLicenseDetailsFromMemoryCache(memoryCache, enumLicenseType);
                if (license != null)
                {
                    jsonData = JsonConvert.SerializeObject(license);
                }

                if (string.IsNullOrEmpty(jsonData))
                {
                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = ErrorCodes.EnumServerCode.NotFound
                    });
                }

                return Ok(
                      new AuthAPIResponseModel
                      {
                          ErrorCode = ErrorCodes.EnumServerCode.OK,
                          Data = aesHelper.Encrypt(jsonData, IV, AES_KEY)
                      }); ;
            }
            catch (Exception ex)
            {
                Log.Error("ValidateLicence :: " + ex.ToString());
                return Ok(new AuthAPIResponseModel
                {
                    ErrorCode = ErrorCodes.EnumServerCode.ServerError
                });
            }
        }

        private LicenseDetail GetLicenseDetailsFromMemoryCache(IMemoryCache memoryCache, int enumLicenseType)
        {
            if (memoryCache.TryGetValue((EnumLicenseType)enumLicenseType, out LicenseDetail licenseDetail))
            {
                return licenseDetail;
            }

            return null;
        }
    }
}
