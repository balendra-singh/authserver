﻿using Enterprise.AuthorizationClientServer.Core.BusinessLogic;
using Enterprise.AuthorizationClientServer.Core.Models;
using Enterprise.AuthorizationClientServer.Core.Models.Contracts;
using Enterprise.AuthorizationClientServer.Core.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using NLog;
using System;
using static Enterprise.AuthorizationClientServer.Core.Models.Contracts.ErrorCodes;

namespace Enterprise.AuthorizationClient.API.Controllers
{
    [ApiController]
    public class ServiceController : ControllerBase
    {
        private readonly Logger Log = LogManager.GetCurrentClassLogger();
        private readonly ContainerRepository containerRepository;
        private readonly string webconnectionstring;
        private readonly string pduFilePath;

        public ServiceController(IConfiguration configuration)
        {
            containerRepository = new ContainerRepository();
            webconnectionstring = configuration.GetSection(nameof(webconnectionstring)).Value;
            pduFilePath = configuration.GetSection(nameof(pduFilePath)).Value;
        }

        [HttpPost("api/service/start")]
        public IActionResult StartService([FromBody] ContainerServiceModel containerServiceModel)
        {
            try
            {
                if (!string.IsNullOrEmpty(containerServiceModel.ImageName) && !string.IsNullOrEmpty(containerServiceModel.ContainerName))
                {
                    ServiceManager.StartContainer(containerServiceModel.DockerServiceName);
                    containerRepository.UpdateContainerStatus(containerServiceModel.ImageName, EnumContainerStatus.Running, webconnectionstring);

                    Log.Info($"Service start requested from admin panel for service image: {containerServiceModel.ImageName}");                    

                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.OK

                    });
                }
                else
                {
                    Log.Error($"Validation failure in start service ImageName: {containerServiceModel.ImageName} | ContainerName {containerServiceModel.ContainerName}");
                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.NotFound

                    });

                }
            }
            catch (Exception ex)
            {
                Log.Error($"StartService :: {ex.ToString()}");

                return Ok(new AuthAPIResponseModel
                {
                    ErrorCode = EnumServerCode.ServerError,
                    Data = ex.Message
                });
            }
        }

        [HttpPost("api/service/stop")]
        public IActionResult StopService([FromBody] ContainerServiceModel containerServiceModel)
        {
            try
            {
                if (!string.IsNullOrEmpty(containerServiceModel.ImageName))
                {
                    ServiceManager.StopContainer(containerServiceModel.ImageName);
                    containerRepository.UpdateContainerStatus(containerServiceModel.ImageName, EnumContainerStatus.Stopped, webconnectionstring);

                    Log.Info($"Service stop requested from admin panel for service image: {containerServiceModel.ImageName}");

                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.OK

                    });
                }
                else
                {
                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.NotFound
                    });
                }
            }
            catch (Exception ex)
            {
                Log.Error($"StopService :: {ex.ToString()}");

                return Ok(new AuthAPIResponseModel
                {
                    ErrorCode = EnumServerCode.ServerError,
                    Data = ex.Message
                });
            }
        }

        [HttpGet("api/service/status")]
        public IActionResult ServiceStatus(string imageName)
        {
            try
            {
                if (!string.IsNullOrEmpty(imageName))
                {
                    if (ServiceManager.GetContainerStatus(imageName))
                    {
                        containerRepository.UpdateContainerStatus(imageName, EnumContainerStatus.Running, webconnectionstring);
                        return Ok(new AuthAPIResponseModel
                        {
                            ErrorCode = EnumServerCode.OK,
                            Data = EnumContainerStatus.Running.ToString()
                        });
                    }
                    else
                    {
                        containerRepository.UpdateContainerStatus(imageName, EnumContainerStatus.Stopped, webconnectionstring);
                        return Ok(new AuthAPIResponseModel
                        {
                            ErrorCode = EnumServerCode.OK,
                            Data = EnumContainerStatus.Stopped.ToString()
                        });
                    }
                }
                else
                {
                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.NotFound
                    });
                }
            }
            catch (Exception ex)
            {
                Log.Error($"ServiceStatus :: {ex.ToString()}");

                return Ok(new AuthAPIResponseModel
                {
                    ErrorCode = EnumServerCode.ServerError,
                    Data = ex.Message
                });
            }
        }

        [HttpGet("api/service/pducapture")]
        public IActionResult PDUCapture(string host, string filter, int timeInterval)
        {
            try
            {
                if (string.IsNullOrEmpty(host) || timeInterval <= 0)
                {
                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.BadRequest
                    });
                }

                string fileName = ServiceManager.GetPDUCaptureFileName(host, filter, timeInterval, pduFilePath);

                if (!string.IsNullOrEmpty(fileName))
                {
                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.OK,
                        Data = fileName
                    });
                }
                else
                {
                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.EmptyResource,
                    });
                }
            }
            catch (Exception ex)
            {
                Log.Error($"PDUCapture :: {ex.ToString()}");

                return Ok(new AuthAPIResponseModel
                {
                    ErrorCode = EnumServerCode.ServerError,
                    Data = ex.Message
                });
            }

        }

        [HttpGet("api/service/command")]
        public IActionResult ExecuteCommand(string command)
        {
            try
            {
                string response = ServiceManager.ExecuteCommand(command);
                if (!string.IsNullOrEmpty(response))
                {
                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.OK,
                        Data = response
                    });
                }
                else
                {
                    return Ok(new AuthAPIResponseModel
                    {
                        ErrorCode = EnumServerCode.EmptyResource,
                    });
                }
            }
            catch (Exception ex)
            {
                Log.Error($"ExecuteCommand :: {ex.ToString()}");

                return Ok(new AuthAPIResponseModel
                {
                    ErrorCode = EnumServerCode.ServerError,
                    Data = ex.Message
                });
            }
        }
    }
}
